//
//  NavigationVoiceManager.swift
//  GuideLight v3
//
//  Complete turn-by-turn voice guidance system with enhanced categories
//  Centralizes all navigation-related voice announcements
//

import Foundation
import AVFoundation
import SwiftUI
import simd

/// Comprehensive voice guidance manager for navigation
@MainActor
final class NavigationVoiceManager: ObservableObject {
    
    // MARK: - Shared Instance
    static let shared = NavigationVoiceManager()
    
    // MARK: - Dependencies
    private let voiceGuide = VoiceGuide.shared
    
    // MARK: - Configuration
    private struct VoiceConfig {
        static let proximityDistance: Float = 10.0          // Announce turns 10m ahead
        static let arrivalDistance: Float = 2.0             // Arrival announcement distance
        static let progressUpdateInterval: Float = 50.0     // Progress updates every 50m
        static let directionRepeatInterval: TimeInterval = 15.0  // Repeat directions every 15s
        static let reassuranceInterval: TimeInterval = 30.0     // Course reassurance every 30s
        static let stepDistanceMapping: Float = 0.75       // Average step length in meters
    }
    
    // MARK: - State Tracking
    @Published private(set) var isNavigationActive: Bool = false
    @Published private(set) var lastAnnouncementTime: Date?
    @Published private(set) var lastProgressDistance: Float = 0
    
    private var currentPath: NavigationPath?
    private var currentMap: IndoorMap?
    private var lastDirectionAnnouncement: Date?
    private var lastReassuranceTime: Date?
    private var announcedWaypoints: Set<UUID> = []
    private var lastProximityWarning: (waypointIndex: Int, time: Date)?
    private var lastRoomEntry: String?
    
    // MARK: - Initialization
    private init() {
        setupNotificationObservers()
    }
    
    // MARK: - Public Interface
    
    /// Start voice guidance for a navigation session
    func startNavigation(with path: NavigationPath, map: IndoorMap) {
        currentPath = path
        currentMap = map
        isNavigationActive = true
        announcedWaypoints.removeAll()
        lastProgressDistance = 0
        lastDirectionAnnouncement = nil
        lastReassuranceTime = nil
        lastProximityWarning = nil
        lastRoomEntry = nil
        
        announceRouteOverview(path, map: map)
    }
    
    /// Update voice guidance based on current navigation progress
    func updateProgress(_ progress: NavigationProgress, currentWaypoint: NavigationWaypoint?) {
        guard isNavigationActive else { return }
        
        // Check for room changes
        if let waypoint = currentWaypoint {
            checkRoomEntry(waypoint)
        }
        
        // Check for proximity warnings
        checkProximityWarnings(progress)
        
        // Provide direction guidance
        provideDirectionGuidance(progress)
        
        // Check for progress updates and reassurance
        checkProgressUpdates(progress)
        checkCourseReassurance(progress)
        
        // Update state
        lastAnnouncementTime = Date()
    }
    
    /// Handle waypoint arrival
    func announceWaypointArrival(_ waypoint: NavigationWaypoint, nextWaypoint: NavigationWaypoint?, isLastWaypoint: Bool) {
        guard isNavigationActive else { return }
        
        // Mark waypoint as announced
        announcedWaypoints.insert(waypoint.id)
        
        let message = buildArrivalMessage(waypoint, nextWaypoint: nextWaypoint, isLastWaypoint: isLastWaypoint)
        speak(message)
        
        // Announce custom audio instruction if available
        if let audioInstruction = waypoint.audioInstruction {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                self.speak(audioInstruction)
            }
        }
    }
    
    /// Handle navigation completion
    func completeNavigation() {
        guard isNavigationActive else { return }
        
        speak("Navigation complete. You have arrived at your destination.")
        endNavigation()
    }
    
    /// Handle navigation cancellation
    func cancelNavigation() {
        guard isNavigationActive else { return }
        
        speak("Navigation cancelled.")
        endNavigation()
    }
    
    /// Handle navigation pause
    func pauseNavigation() {
        speak("Navigation paused.")
    }
    
    /// Handle navigation resume
    func resumeNavigation() {
        speak("Navigation resumed.")
        lastDirectionAnnouncement = nil // Force direction update
    }
    
    // MARK: - Announcements Category
    
    /// Landing page announcement about the app and voice usage
    func announceLandingPage() {
        let announcement = "Welcome to GuideLight, your indoor navigation companion. " +
                          "Say 'Hey GuideLight' followed by commands like 'start navigation', " +
                          "'take me to the kitchen', or 'help' to interact with the app using your voice."
        speak(announcement)
    }
    
    /// Announce current location when navigation starts
    func announceCurrentLocation(_ map: IndoorMap, userPosition: simd_float3) {
        // Try to determine current room and nearby landmarks
        let currentRoom = determineUserRoom(position: userPosition, map: map)
        let nearbyLandmarks = findNearbyLandmarks(position: userPosition, map: map)
        
        var locationDescription = "You are currently "
        
        if let room = currentRoom {
            locationDescription += "in the \(room.name.lowercased())"
            if !room.description?.isEmpty ?? true {
                locationDescription += ", \(room.description!)"
            }
        } else {
            locationDescription += "at your starting position"
        }
        
        // Add map context if available
        if !map.name.isEmpty {
            locationDescription += " in \(map.name)"
        }
        
        // Add nearby landmarks
        if !nearbyLandmarks.isEmpty {
            let landmarkNames = nearbyLandmarks.prefix(2).map(\.name).joined(separator: " and ")
            locationDescription += ". Nearby landmarks include \(landmarkNames)"
        }
        
        locationDescription += "."
        
        speak(locationDescription)
    }
    
    // MARK: - Route Planning Category
    
    private func announceRouteOverview(_ path: NavigationPath, map: IndoorMap) {
        let totalSteps = Int(path.totalDistance / VoiceConfig.stepDistanceMapping)
        let time = formatTime(path.estimatedTime)
        let destinationName = getDestinationName(from: path)
        
        var overview = "Route calculated to \(destinationName). "
        overview += "Total distance: \(totalSteps) steps. "
        overview += "Estimated time: \(time). "
        
        // Add room traversal information
        if !path.roomsTraversed.isEmpty && path.roomsTraversed.count > 1 {
            let roomNames = path.roomsTraversed.compactMap { roomId in
                map.room(withId: roomId)?.name
            }
            if roomNames.count > 1 {
                overview += "Route passes through \(roomNames.count) rooms: \(roomNames.joined(separator: ", ")). "
            }
        }
        
        overview += "Starting navigation."
        
        speak(overview)
    }
    
    // MARK: - Turn-by-Turn Instructions Category
    
    private func provideDirectionGuidance(_ progress: NavigationProgress) {
        // Don't repeat directions too frequently
        if let lastTime = lastDirectionAnnouncement,
           Date().timeIntervalSince(lastTime) < VoiceConfig.directionRepeatInterval {
            return
        }
        
        // Only provide guidance if not well aligned
        guard !progress.isAligned else { return }
        
        let instruction = buildDirectionInstruction(progress)
        speak(instruction)
        lastDirectionAnnouncement = Date()
    }
    
    private func buildDirectionInstruction(_ progress: NavigationProgress) -> String {
        let steps = Int(progress.distanceToNextWaypoint / VoiceConfig.stepDistanceMapping)
        let clockInstruction = progress.voiceClockInstructionText
        
        // If very close, just give direction
        if progress.distanceToNextWaypoint < 3.0 {
            return clockInstruction
        }
        
        // For longer distances, include step count
        return "After \(steps) steps, \(clockInstruction.lowercased())"
    }
    
    /// Announce doorway interaction (push/pull/slide)
    func announceDoorwayAction(_ doorway: NavigationWaypoint, fromRoom: String, toRoom: String) {
        guard let map = currentMap,
              let doorwayFromMap = map.doorways.first(where: { $0.id.uuidString == doorway.doorwayId }) else {
            return
        }
        
        let action = doorwayFromMap.action(from: fromRoom, to: toRoom)
        let toRoomName = map.room(withId: toRoom)?.name ?? "next room"
        
        var actionMessage = ""
        switch action {
        case .push:
            actionMessage = "Push door to enter \(toRoomName)"
        case .pull:
            actionMessage = "Pull door to enter \(toRoomName)"
        case .slide:
            actionMessage = "Slide door to enter \(toRoomName)"
        case .automatic:
            actionMessage = "Door opens automatically, walk through to \(toRoomName)"
        case .walkThrough:
            actionMessage = "Walk through to \(toRoomName)"
        }
        
        speak(actionMessage)
    }
    
    /// Announce room entry with floor surface information
    func announceRoomEntry(_ room: Room) {
        guard lastRoomEntry != room.id.uuidString else { return }
        
        lastRoomEntry = room.id.uuidString
        
        var message = "Entering \(room.name.lowercased())"
        
        // Add room context
        if room.type != .general {
            message += ", a \(room.type.audioContext)"
        }
        
        // Add floor surface information
        message += ". Floor surface is \(room.floorSurface.displayName.lowercased())"
        
        // Add echo information for spatial awareness
        if room.floorSurface.echoLevel != "medium echo" {
            message += " with \(room.floorSurface.echoLevel)"
        }
        
        message += "."
        
        speak(message)
    }
    
    // MARK: - Proximity Warnings Category
    
    private func checkProximityWarnings(_ progress: NavigationProgress) {
        guard let path = currentPath else { return }
        
        let currentIndex = progress.currentWaypointIndex
        let nextIndex = currentIndex + 1
        
        // Check if we're approaching the next waypoint
        if nextIndex < path.waypoints.count,
           progress.distanceToNextWaypoint <= VoiceConfig.proximityDistance {
            
            // Avoid duplicate announcements
            if let lastWarning = lastProximityWarning,
               lastWarning.waypointIndex == nextIndex,
               Date().timeIntervalSince(lastWarning.time) < 8.0 {
                return
            }
            
            let nextWaypoint = path.waypoints[nextIndex]
            let message = buildProximityWarning(for: nextWaypoint, distance: progress.distanceToNextWaypoint)
            if !message.isEmpty {
                speak(message)
                lastProximityWarning = (nextIndex, Date())
            }
        }
    }
    
    private func buildProximityWarning(for waypoint: NavigationWaypoint, distance: Float) -> String {
        let steps = Int(distance / VoiceConfig.stepDistanceMapping)
        
        switch waypoint.type {
        case .doorway:
            return "In \(steps) steps, approaching \(waypoint.voiceName)"
        case .destination:
            return "In \(steps) steps, arriving at \(waypoint.voiceName)"
        case .intermediate:
            if !waypoint.name.isEmpty {
                return "In \(steps) steps, passing \(waypoint.name)"
            }
            return "" // Skip generic intermediate waypoints
        case .start:
            return "" // Should not occur
        }
    }
    
    /// Announce landmark notifications
    func announceLandmark(_ landmark: String) {
        speak("Landmark detected: \(landmark)")
    }
    
    // MARK: - Progress Updates Category
    
    private func checkProgressUpdates(_ progress: NavigationProgress) {
        let currentDistance = progress.totalDistanceRemaining
        let distanceTraveled = lastProgressDistance - currentDistance
        
        // Announce progress every 50 meters traveled
        if distanceTraveled >= VoiceConfig.progressUpdateInterval {
            announceProgress(progress)
            lastProgressDistance = currentDistance
        }
    }
    
    private func announceProgress(_ progress: NavigationProgress) {
        let remainingSteps = Int(progress.totalDistanceRemaining / VoiceConfig.stepDistanceMapping)
        let timeRemaining = formatTime(progress.estimatedTimeRemaining)
        let percent = Int(progress.percentComplete * 100)
        
        let message = "\(percent)% complete. \(remainingSteps) steps remaining. Estimated time: \(timeRemaining)."
        speak(message)
    }
    
    /// Provide course reassurance
    private func checkCourseReassurance(_ progress: NavigationProgress) {
        // Only provide reassurance if user is aligned and it's been a while
        guard progress.isAligned else { return }
        
        if let lastTime = lastReassuranceTime,
           Date().timeIntervalSince(lastTime) < VoiceConfig.reassuranceInterval {
            return
        }
        
        speak("You're on the correct course. Keep going straight.")
        lastReassuranceTime = Date()
    }
    
    // MARK: - Arrival Confirmations Category
    
    private func buildArrivalMessage(_ waypoint: NavigationWaypoint, nextWaypoint: NavigationWaypoint?, isLastWaypoint: Bool) -> String {
        if isLastWaypoint {
            // Final destination
            return "Arrived at \(waypoint.voiceName)."
        }
        
        // Intermediate waypoint
        let arrivedText = "Arrived at \(waypoint.voiceName)"
        
        guard let next = nextWaypoint else {
            return arrivedText + "."
        }
        
        let nextText = getNextWaypointDescription(next)
        return arrivedText + ". " + nextText + "."
    }
    
    private func getNextWaypointDescription(_ waypoint: NavigationWaypoint) -> String {
        switch waypoint.type {
        case .doorway:
            return "Proceed to \(waypoint.voiceName)"
        case .destination:
            return "Proceeding to \(waypoint.voiceName)"
        case .intermediate:
            if !waypoint.name.isEmpty {
                return "Continue toward \(waypoint.name)"
            }
            return "Continue forward"
        case .start:
            return "Continue"
        }
    }
    
    // MARK: - Error Handling Category
    
    func announceNavigationError(_ error: String) {
        speak("Navigation error: \(error)")
    }
    
    func announceRecalculation() {
        speak("Route updated. Recalculating path.")
    }
    
    func announceOffRoute() {
        speak("You appear to be off the planned route. Please return to the path or I'll recalculate.")
    }
    
    func announceNoRouteFound() {
        speak("Sorry, I couldn't find a route to that destination. Please try a different location.")
    }
    
    func announceMapLoadingError() {
        speak("Unable to load map data. Please check your map selection and try again.")
    }
    
    // MARK: - Voice Command Responses
    
    /// Handle voice destination requests
    func handleDestinationRequest(_ destination: String, navigationViewModel: NavigationViewModel, arSession: ARSession) async {
        guard let frame = arSession.currentFrame else {
            speak("Camera not ready yet.")
            return
        }
        
        let trimmed = destination.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            speak("Say, show me the path to, followed by a destination.")
            return
        }
        
        let currentPosition = CoordinateTransformManager.extractPosition(from: frame.camera)
        
        let result = await navigationViewModel.selectDestination(named: trimmed, session: arSession, currentPosition: currentPosition)
        
        switch result {
        case .success(let pickedName):
            speak("Taking you to \(pickedName).")
        case .ambiguous(let options):
            handleAmbiguousDestination(options)
        case .notFound:
            speak("I couldn't find \(trimmed) in this map.")
        }
    }
    
    private func handleAmbiguousDestination(_ options: [Beacon]) {
        let list = options.prefix(3).map(\.name)
        
        if list.count == 2 {
            speak("I found \(list[0]) and \(list[1]). Say first or second.")
        } else if list.count >= 3 {
            speak("I found \(list[0]), \(list[1]), and \(list[2]). Say first, second, or third.")
        } else if list.count == 1 {
            speak("Found \(list[0]). Say yes to confirm.")
        }
    }
    
    // MARK: - System Messages (Legacy Support)
    
    func announceNavigationScreen() {
        speak("Navigation screen.")
    }
    
    func announceCameraNotReady() {
        speak("Camera not ready yet.")
    }
    
    func announceNeedCameraAccess() {
        speak("I need camera access.")
    }
    
    func announceDestinationNotFound(_ name: String) {
        speak("I couldn't find \(name) in this map.")
    }
    
    func announceStartingGuidance(_ destinationName: String) {
        speak("Starting guidance to \(destinationName).")
    }
    
    // MARK: - Helper Methods
    
    private func checkRoomEntry(_ waypoint: NavigationWaypoint) {
        guard let map = currentMap,
              let room = map.room(withId: waypoint.roomId),
              lastRoomEntry != room.id.uuidString else {
            return
        }
        
        announceRoomEntry(room)
    }
    
    private func determineUserRoom(position: simd_float3, map: IndoorMap) -> Room? {
        // Find closest beacon to determine room
        var closestBeacon: Beacon?
        var minDistance: Float = Float.infinity
        
        for beacon in map.beacons {
            let distance = simd_distance(position, beacon.position)
            if distance < minDistance {
                minDistance = distance
                closestBeacon = beacon
            }
        }
        
        guard let beacon = closestBeacon else { return nil }
        return map.room(withId: beacon.roomId)
    }
    
    private func findNearbyLandmarks(position: simd_float3, map: IndoorMap, maxDistance: Float = 5.0) -> [Beacon] {
        return map.beacons
            .filter { simd_distance(position, $0.position) <= maxDistance }
            .filter { !$0.name.isEmpty && $0.category != .navigation }
            .sorted { simd_distance(position, $0.position) < simd_distance(position, $1.position) }
    }
    
    private func speak(_ message: String) {
        voiceGuide.speak(message)
    }
    
    private func endNavigation() {
        isNavigationActive = false
        currentPath = nil
        currentMap = nil
        announcedWaypoints.removeAll()
        lastProgressDistance = 0
        lastDirectionAnnouncement = nil
        lastReassuranceTime = nil
        lastProximityWarning = nil
        lastRoomEntry = nil
    }
    
    private func getDestinationName(from path: NavigationPath) -> String {
        if let destination = path.waypoints.last(where: { $0.type == .destination }) {
            return destination.name.isEmpty ? "destination" : destination.name
        }
        return "destination"
    }
    
    private func formatTime(_ time: TimeInterval) -> String {
        let minutes = Int(time) / 60
        let seconds = Int(time) % 60
        
        if minutes > 0 {
            if seconds > 30 {
                return "\(minutes + 1) minutes"
            } else {
                return "\(minutes) minutes"
            }
        } else {
            return "\(max(30, seconds)) seconds"
        }
    }
    
    // MARK: - Notification Observers
    
    private func setupNotificationObservers() {
        NotificationCenter.default.addObserver(
            forName: .glVoiceNavigateCommand,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            // Handle navigation requests from voice commands
            // This integrates with your existing voice command system
        }
    }
}

// MARK: - Extensions for NavigationProgress

extension NavigationProgress {
    /// Enhanced clock instruction text with better voice formatting
    var voiceClockInstructionText: String {
        let degrees = headingErrorDegrees
        
        // Perfect alignment (±5°)
        if abs(degrees) <= 5 {
            return "Continue straight ahead"
        }
        
        // Near alignment (5°-15°)
        if abs(degrees) <= 15 {
            return "Slight \(turnDirection) turn"
        }
        
        // Behind (165°-195°)
        if abs(degrees) >= 165 {
            return "Turn around, destination is behind you"
        }
        
        // Standard clock positions with voice-friendly phrasing
        let hour = clockPosition
        return "Turn \(turnDirection) to your \(hour) o'clock"
    }
}

// MARK: - Voice-Optimized Extensions

extension NavigationWaypoint {
    /// Get voice-friendly name for announcements
    var voiceName: String {
        if name.isEmpty {
            switch type {
            case .start: return "starting point"
            case .intermediate: return "waypoint"
            case .doorway: return "doorway"
            case .destination: return "destination"
            }
        }
        return name
    }
}

// MARK: - Integration Helper

extension NavigationVoiceManager {
    /// Static method for easy integration with existing code
    static func speak(_ message: String) {
        shared.speak(message)
    }
    
    /// Replace existing VoiceGuide.shared.speak calls for navigation
    static func announceArrival(_ waypoint: NavigationWaypoint, next: NavigationWaypoint? = nil, isLast: Bool = false) {
        shared.announceWaypointArrival(waypoint, nextWaypoint: next, isLastWaypoint: isLast)
    }
}
