// NavigationViewModel+Voice.swift
import Foundation
import ARKit

extension NavigationViewModel {
    /// Finds a destination by name/substring and starts guidance using current camera position.
    /// UPDATED: Now uses NavigationVoiceManager for voice feedback
    func navigateToPOI(named name: String, session: ARSession) {
        guard let frame = session.currentFrame else {
            NavigationVoiceManager.shared.announceNeedCameraAccess()
            return
        }
        let t = frame.camera.transform
        let currentPos = SIMD3<Float>(t.columns.3.x, t.columns.3.y, t.columns.3.z)

        // Prefer exact (case-insensitive), then contains
        let candidates = availableDestinations
        let lc = name.lowercased()
        let dest = candidates.first(where: { $0.name.lowercased() == lc }) ??
                   candidates.first(where: { $0.name.lowercased().contains(lc) })

        guard let target = dest else {
            NavigationVoiceManager.shared.announceDestinationNotFound(name)
            return
        }
        selectDestination(target, currentPosition: currentPos, session: session)
        NavigationVoiceManager.shared.announceStartingGuidance(target.name)
    }
}
